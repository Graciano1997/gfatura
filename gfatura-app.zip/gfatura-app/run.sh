#!/bin/bash
echo "Starting GFatura..."
java -cp "gfatura.jar:lib/*" Main
